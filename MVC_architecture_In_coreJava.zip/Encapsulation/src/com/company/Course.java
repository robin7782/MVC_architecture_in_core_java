package com.company;

public class Course {
    private String CourseName;
    private String CourseId;
    private String CourseCategory;
    //getting the information
    public String getId(){ return CourseId;}
    public String getName(){ return CourseName;}
    public String getCouseC(){ return CourseCategory;}

    // setting all the information to the world

    public void setId(String id){
        this.CourseId = id;
    }
    public void setName(String name){
        this.CourseName = name;
    }
    public void setCourseName(String cname){
        this.CourseCategory = cname;
    }
}
