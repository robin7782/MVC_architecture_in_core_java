package com.company;

public class CourseController {
    private Course model;
    private CourseView view;

    public CourseController(Course m, CourseView v){
        this.model = m;
        this.view = v;
    }
    public void setCourseName(String cn){
        model.setName(cn);
    }
    public String getCourseName(){
       return model.getName();
    }
    public void setCouseId(String id){
        model.setId(id);
    }
    public String getCourseId(){
        return model.getId();
    }
    public void setCourseCatergory(String cc){
        model.setCourseName(cc);
    }
    public String getCourseCategory(){
        return model.getCouseC();
    }
    public void updateView(){
        view.printCourseDetails(model.getName(),model.getId(),model.getCouseC());
    }

}
