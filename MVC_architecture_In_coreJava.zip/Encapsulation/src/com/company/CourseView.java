package com.company;

public class CourseView {
    public void printCourseDetails(String cn,String cid,String cc){
        System.out.println(" Course Details");
        System.out.println("Name: " + cn);
        System.out.println("Course ID " + cid);
        System.out.println("Course Category " + cc);
    }
}
