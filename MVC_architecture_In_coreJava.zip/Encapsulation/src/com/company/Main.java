package com.company;

public class Main {

    public static void main(String[] args) {

        Course model = retriveCourseFromDatabase();
        CourseView view = new CourseView();
        CourseController contoller = new CourseController(model,view);

        contoller.updateView();

        contoller.setCourseName("Physics");
        System.out.println("After upating Course details");

        contoller.updateView();

    }




    private static Course retriveCourseFromDatabase(){
        Course course = new Course();
        course.setName("Robin");
        course.setId("8756");
        course.setCourseName("Data Stucture");
        return course;
    }
}
